package Builder.exBanca;

public interface Builder {
    ContBancar build();
}
