package Builder.exBanca;

public class Main {

    public static void main(String[] args) {
        ContBancar cont = new ContBancar();
        cont.setDetinator("Popescu");
        cont.setSuma(2000);
        cont.setMoneda("Ron");
        cont.setContSalariu(true);
        cont.setInternetBanking(true);
        cont.setContSalariu(true);

        System.out.println(cont.toString());
    }
}
