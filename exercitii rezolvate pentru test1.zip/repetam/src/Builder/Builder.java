package Builder;

public interface Builder {
    PachetTransport build();
}
