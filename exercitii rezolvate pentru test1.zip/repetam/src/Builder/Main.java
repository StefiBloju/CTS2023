package Builder;

public class Main {
    public static void main(String[] args) {
        PachetTransport pachetTransport=new PachetTransportBuilder()
                .setHasAC(true).setHasTV(true).setHasWiFi(true).build();
        System.out.println(pachetTransport.toString());
    }
}
