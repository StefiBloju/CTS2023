package Factory.method;

public class Main {

    public static void afisare(Factory fabrica) {
        PachetTuristic pachetTuristic = fabrica.createPachet();
        pachetTuristic.descriere();
    }

    public static void main(String[] args) {
        afisare(new FactoryPachetCazare());
    }
}
