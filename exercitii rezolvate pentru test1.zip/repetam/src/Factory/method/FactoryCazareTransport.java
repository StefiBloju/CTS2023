package Factory.method;

public class FactoryCazareTransport implements Factory{
    @Override
    public PachetTuristic createPachet() {
        return new PachetCazareTransport();
    }
}
