package Factory.method;

public interface PachetTuristic {
    void descriere();
}
