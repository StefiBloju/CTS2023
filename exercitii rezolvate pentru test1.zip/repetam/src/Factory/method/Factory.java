package Factory.method;

public interface Factory {
    PachetTuristic createPachet();
}
