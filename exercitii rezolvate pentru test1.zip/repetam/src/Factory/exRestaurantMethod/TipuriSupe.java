package Factory.exRestaurantMethod;

public interface TipuriSupe {
    void descriere();
}
