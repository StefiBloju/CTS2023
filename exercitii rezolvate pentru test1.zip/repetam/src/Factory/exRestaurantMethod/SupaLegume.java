package Factory.exRestaurantMethod;

public class SupaLegume implements TipuriSupe{
    @Override
    public void descriere() {
        System.out.println("Aceasta supa contine legume");
    }
}
