package Factory.exRestaurantMethod;

public class FactorySupaLegume implements Factory{
    @Override
    public TipuriSupe createSupa() {
        return new SupaLegume();
    }
}
