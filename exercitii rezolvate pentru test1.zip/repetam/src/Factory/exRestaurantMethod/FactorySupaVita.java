package Factory.exRestaurantMethod;

public class FactorySupaVita implements Factory{
    @Override
    public TipuriSupe createSupa() {
        return new SupaVita();
    }
}
