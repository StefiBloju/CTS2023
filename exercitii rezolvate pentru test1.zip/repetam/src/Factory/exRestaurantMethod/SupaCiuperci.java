package Factory.exRestaurantMethod;

public class SupaCiuperci implements TipuriSupe{
    @Override
    public void descriere() {
        System.out.println("Aceasta supa contine ciuperci");
    }
}
