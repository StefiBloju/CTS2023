package Factory.exRestaurantMethod;

public interface Factory {
    TipuriSupe createSupa();
}
