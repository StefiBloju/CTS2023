package Factory.exRestaurantMethod;

public class FactorySupaCiuperci implements Factory{
    @Override
    public TipuriSupe createSupa() {
        return new SupaCiuperci();
    }
}
