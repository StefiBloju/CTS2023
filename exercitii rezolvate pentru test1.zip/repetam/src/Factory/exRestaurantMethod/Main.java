package Factory.exRestaurantMethod;

public class Main {

   public static void afisare(Factory fabrica){
       TipuriSupe tipuriSupe = fabrica.createSupa();
       tipuriSupe.descriere();
   }

    public static void main(String[] args) {
        afisare(new FactorySupaCiuperci());
    }
}
