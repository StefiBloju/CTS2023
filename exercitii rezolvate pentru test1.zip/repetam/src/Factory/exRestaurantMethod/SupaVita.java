package Factory.exRestaurantMethod;

public class SupaVita implements TipuriSupe{
    @Override
    public void descriere() {
        System.out.println("Aceasta supa contine carne de vita");
    }
}
