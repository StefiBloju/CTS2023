package Factory.exSpitalSimple;

public class Asistent implements PersonalSpital{
    @Override
    public void descriere() {
        System.out.println("Acest post este de Asistent");
    }
}
