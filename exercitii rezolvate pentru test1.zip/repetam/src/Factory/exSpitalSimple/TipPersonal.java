package Factory.exSpitalSimple;

public enum TipPersonal {
    brancardier, asistent, medic
}
