package Factory.exSpitalSimple;

public class Brancardier implements PersonalSpital{
    @Override
    public void descriere() {
        System.out.println("Aceste post este de Brancardier");
    }
}
