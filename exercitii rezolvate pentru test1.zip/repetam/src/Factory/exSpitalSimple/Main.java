package Factory.exSpitalSimple;

public class Main {

    public static void main(String[] args) {
        PersonalFactory personalFactory = new PersonalFactory();
        PersonalSpital personalSpital = null;

        try{
            personalSpital = personalFactory.createPersonal(TipPersonal.asistent);
        } catch (Exception e) {
            e.printStackTrace();
        }

        personalSpital.descriere();
    }
}
