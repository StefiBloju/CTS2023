package Factory.exSpitalSimple;

public class PersonalFactory {

    public PersonalSpital createPersonal(TipPersonal tipPersonal) throws Exception {
        switch (tipPersonal){
            case brancardier:
                return new Brancardier();
            case medic:
                return new Medic();
            case asistent:
                return new Asistent();
            default:
                throw new Exception("Acest post nu exista");
        }
    }
}
