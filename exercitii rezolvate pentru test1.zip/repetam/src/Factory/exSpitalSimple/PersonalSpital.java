package Factory.exSpitalSimple;

public interface PersonalSpital {
    void descriere();
}
