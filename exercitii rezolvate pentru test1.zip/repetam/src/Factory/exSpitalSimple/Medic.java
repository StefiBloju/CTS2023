package Factory.exSpitalSimple;

public class Medic implements PersonalSpital{
    @Override
    public void descriere() {
        System.out.println("Acest post este de Medic");
    }
}
