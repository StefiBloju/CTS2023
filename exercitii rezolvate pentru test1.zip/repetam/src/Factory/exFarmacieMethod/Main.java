package Factory.exFarmacieMethod;

import Factory.exSpitalMethod.Medic;

public class Main {

    public static void main(String[] args) {
        FactoryBody body = new FactoryBody();
        FactoryDurere durere = new FactoryDurere();

        Medicamente m1 = body.createMedicament("gel", 22);
        Medicamente m2 = durere.createMedicament("pastila", 50);

        System.out.println(m1);
        System.out.println(m2);
    }
}
