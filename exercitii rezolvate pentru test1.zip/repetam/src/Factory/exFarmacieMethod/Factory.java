package Factory.exFarmacieMethod;

public interface Factory {
    Medicamente createMedicament(String denumire, float pret);
}
