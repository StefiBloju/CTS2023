package Factory.exFarmacieMethod;

public class Durere extends Medicamente{
    public Durere(String denumire, float pret) {
        super(denumire, pret, TipMedicamente.durere);
    }
}
