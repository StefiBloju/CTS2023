package Factory.exFarmacieMethod;

public class FactoryRaceala implements Factory{
    @Override
    public Medicamente createMedicament(String denumire, float pret) {
        return new Raceala(denumire, pret);
    }
}
