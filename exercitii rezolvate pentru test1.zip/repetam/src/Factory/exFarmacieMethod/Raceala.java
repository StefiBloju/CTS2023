package Factory.exFarmacieMethod;

public class Raceala extends Medicamente{
    public Raceala(String denumire, float pret) {
        super(denumire, pret, TipMedicamente.raceala);
    }
}
