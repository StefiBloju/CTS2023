package Factory.exFarmacieMethod;

public abstract class Medicamente {
    private String denumire;
    private float pret;

    private TipMedicamente tip;


    public Medicamente(String denumire, float pret, TipMedicamente tip) {
        this.denumire = denumire;
        this.pret = pret;
        this.tip = tip;
    }

    public String getDenumire() {
        return denumire;
    }

    public float getPret() {
        return pret;
    }

    public TipMedicamente getTip() {
        return tip;
    }

    @Override
    public String toString() {
        return "Medicamente{" +
                "denumire='" + denumire + '\'' +
                ", pret=" + pret +
                ", tip=" + tip +
                '}';
    }
}
