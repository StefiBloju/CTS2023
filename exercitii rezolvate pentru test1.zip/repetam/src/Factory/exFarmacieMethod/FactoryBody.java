package Factory.exFarmacieMethod;

public class FactoryBody implements Factory{
    @Override
    public Medicamente createMedicament(String denumire, float pret) {
        return new Body(denumire, pret);
    }
}
