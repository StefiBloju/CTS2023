package Factory.exFarmacieMethod;

public class Body extends Medicamente{
    public Body(String denumire, float pret) {
        super(denumire, pret, TipMedicamente.body);
    }
}
