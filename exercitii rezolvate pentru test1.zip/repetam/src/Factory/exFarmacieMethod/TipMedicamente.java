package Factory.exFarmacieMethod;

public enum TipMedicamente {
    durere, body, raceala
}
