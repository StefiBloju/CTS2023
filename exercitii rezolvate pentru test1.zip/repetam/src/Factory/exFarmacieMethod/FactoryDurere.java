package Factory.exFarmacieMethod;

public class FactoryDurere implements Factory{
    @Override
    public Medicamente createMedicament(String denumire, float pret) {
        return new Durere(denumire, pret);
    }
}
