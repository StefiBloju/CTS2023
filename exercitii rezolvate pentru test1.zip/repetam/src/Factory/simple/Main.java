package Factory.simple;

public class Main {
    public static void main(String[] args) {
        AgentieFactory agentieFactory = new AgentieFactory();
        PachetTuristic pachetTuristic = null;

        try {
            pachetTuristic =agentieFactory.createPachet(TipPachet.pachetCazare);
        }catch (Exception e) {
            e.printStackTrace();
        }

        pachetTuristic.descriere();
    }
}
