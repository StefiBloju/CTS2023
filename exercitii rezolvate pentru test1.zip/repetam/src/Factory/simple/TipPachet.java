package Factory.simple;

public enum TipPachet {
    pachetCazare, pachetTransport, pachetCazareSiTransport
}
