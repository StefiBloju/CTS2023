package Factory.simple;

public class PachetCazareTransport implements PachetTuristic{
    @Override
    public void descriere() {
        System.out.println("Acest pachet contine cazare si transport");
    }
}
