package Factory.simple;

public interface PachetTuristic {
    void descriere();
}
