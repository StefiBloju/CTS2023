package Factory.exSpitalMethod;

public class Brancardier implements PersonalSpital{
    @Override
    public void descriere() {
        System.out.println("Acest post este de brancardier");
    }
}
