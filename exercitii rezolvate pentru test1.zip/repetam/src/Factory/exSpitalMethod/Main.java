package Factory.exSpitalMethod;

public class Main {

    public static void afisare(Factory fabrica){
        PersonalSpital personalSpital = fabrica.createPersonal();
        personalSpital.descriere();
    }

    public static void main(String[] args) {
        afisare(new FactoryBrancardier());
    }
}
