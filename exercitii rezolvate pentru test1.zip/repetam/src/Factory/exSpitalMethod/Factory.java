package Factory.exSpitalMethod;

public interface Factory {
    PersonalSpital createPersonal();
}
