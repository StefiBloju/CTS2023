package Factory.exSpitalMethod;

public interface PersonalSpital {
    void descriere();
}
