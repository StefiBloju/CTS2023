package Prototype.exBanca;

import java.util.HashMap;

public class Prototype {
    private static final HashMap<Boolean, Client> prototipuri = new HashMap<>();
    static {
        prototipuri.put(true, new ClientExistent(new Object()));
        prototipuri.put(false, new ClientNou(new Object()));
    }

    public static Client getClient(Boolean status){
        Client client = prototipuri.get(status);
        if(client != null) return client.clone();
        else return null;
    }
}
