package Prototype.exBanca;

public class ClientNou extends Client{
    public ClientNou(Object object) {
        super(object);
    }

    @Override
    public void afiseasaDetalii(){
        System.out.println("Trebuie sa introduca datele.");
    }
}
