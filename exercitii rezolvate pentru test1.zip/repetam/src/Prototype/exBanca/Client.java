package Prototype.exBanca;

import Prototype.exFarmacie.Reteta;

public abstract class Client implements Cloneable{
    private Object object;

    public Client(Object object) {
        this.object = object;
    }

    public Object getObject() {
        return object;
    }

    public void setObject(Object object) {
        this.object = object;
    }

    public abstract void afiseasaDetalii();

    @Override
    public Client clone(){
        try{
            Client clone = (Client) super.clone();
            clone.object=new Object();
            return clone;
        }catch (CloneNotSupportedException e){
            throw new AssertionError();
        }
    }
}
