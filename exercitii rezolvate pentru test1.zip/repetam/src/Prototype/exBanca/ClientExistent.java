package Prototype.exBanca;

public class ClientExistent extends Client{
    public ClientExistent(Object object) {
        super(object);
    }

    @Override
    public void afiseasaDetalii() {
        System.out.println("Nu este nevoie sa introduca datele");
    }
}
