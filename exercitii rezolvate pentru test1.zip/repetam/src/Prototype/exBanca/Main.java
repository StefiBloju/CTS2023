package Prototype.exBanca;

public class Main {
    public static void main(String[] args) {
        ClientNou cn1 = (ClientNou) Prototype.getClient(false);
        ClientNou cn2 = (ClientNou) Prototype.getClient(false);
        ClientExistent ce1 = (ClientExistent) Prototype.getClient(true);
        ClientExistent ce2 = (ClientExistent) Prototype.getClient(true);

//        if(cn1.getObject() == cn2.getObject()) System.out.println("Nu a fost realizat un deep copy");
//        else System.out.println("A fost realizat un deep copy");
//
//        if(ce1.getObject() == ce2.getObject()) System.out.println("Nu a fost realizat un deep copy");
//        else System.out.println("A fost realizat un deep copy");

        if(ce1.getObject().equals(false))
            System.out.println("Necesita prezentarea datelor");
        else
            System.out.println("Datele sunt deja colectate");


        if(cn1.getObject().equals(true))
            System.out.println("Datele sunt deja colectate");
        else
            System.out.println("Necesita prezentarea datelor");
    }

}






// Banca dorește sa implementeze un modul în cadrul aplicației, astfel încât daca un client deține deja un cont la banca
// și dorește deschiderea unui nou cont sa nu fie necesara reconstruirea datelor despre respectivul client,
// deoarece prin construire clientul trebuie sa prezinte iar documentele necesare precum buletin și cardul
// de credit pentru plata.