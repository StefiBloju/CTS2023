package Prototype.exFarmacie;

public class RetetaXanax extends Reteta{
    public RetetaXanax(Object object) {
        super(object);
    }

    @Override
    public void afiseazaInfo() {
        System.out.println("Xanax");
    }
}
