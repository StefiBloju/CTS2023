package Prototype.exFarmacie;

import java.util.HashMap;

public class Prototype {

    private static final HashMap<String, Reteta> prototipuri = new HashMap<>();
    static {
        prototipuri.put("nurofen", new RetetaNurofen(new Object()));
        prototipuri.put("xanax", new RetetaXanax(new Object()));
    }

    public static Reteta getReteta(String tip){
        Reteta reteta = prototipuri.get(tip);
        if(reteta != null) return reteta.clone();
        else return null;
    }
}
