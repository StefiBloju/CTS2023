package Prototype.exFarmacie;

public abstract class Reteta implements Cloneable{
    private Object object;

    public Reteta(Object object) {
        this.object = object;
    }

    public Object getObject() {
        return object;
    }

    public void setObject(Object object) {
        this.object = object;
    }

    public abstract void afiseazaInfo();

    @Override
    public Reteta clone(){
        try{
            Reteta clone = (Reteta) super.clone();
            clone.object=new Object();
            return clone;
        }catch (CloneNotSupportedException e){
            throw new AssertionError();
        }
    }

}
