package Prototype.exFarmacie;

public class RetetaNurofen extends Reteta{
    public RetetaNurofen(Object object) {
        super(object);
    }

    @Override
    public void afiseazaInfo() {
        System.out.println("Nurofen");
    }
}
