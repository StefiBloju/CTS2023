package Prototype.exFarmacie;

public class Main {
    public static void main(String[] args) {
        RetetaNurofen nurofen1 = (RetetaNurofen) Prototype.getReteta("nurofen");
        RetetaNurofen nurofen2 = (RetetaNurofen) Prototype.getReteta("nurofen");
        RetetaXanax xanax1 = (RetetaXanax) Prototype.getReteta("xanax");
        RetetaXanax xanax2 = (RetetaXanax) Prototype.getReteta("xanax");

        if(nurofen1.getObject() == nurofen2.getObject()) System.out.println("Nu a fost realizat un deep copy");
        else System.out.println("A fost realizat un deep copy");

        if(xanax1.getObject() == xanax2.getObject()) System.out.println("Nu a fost realizat un deep copy");
        else System.out.println("A fost realizat un deep copy");

    }
}
