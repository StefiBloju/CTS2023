package Singleton;

public class Main {
    public static void main(String[] args) {
        Agentie primaAgentie = Agentie.getInstance("stef", 1000, 3);
        Agentie aDouaAgentie = Agentie.getInstance("adri", 3000, 5);

        System.out.println(primaAgentie.getNumeAgentie());
        System.out.println(aDouaAgentie.getNumeAgentie());
    }
}


//Clasa Agentie implementează Singleton, astfel încât există o singură instanță a acesteia în întreaga aplicație.
// Metoda getInstance returnează aceeași instanță pentru orice apel.
//
//În metoda main, se creează două obiecte Agentie prin apelul metodei getInstance. Deoarece acestea sunt obiecte
// diferite, dar metoda getInstance întoarce aceeași instanță pentru orice apel, compararea acestor două obiecte
//va returna true, ceea ce înseamnă că acestea sunt aceeași instanță și se va afișa "Aceeasi agentie".