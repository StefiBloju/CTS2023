package Singleton;

public class Agentie {
    private String numeAgentie;
    private float capital;
    private int nrAngajati;

    //instanta statica
    private static Agentie instance=null;

    //Constructor privat
    public Agentie(String numeAgentie, float capital, int nrAngajati) {
        this.numeAgentie = numeAgentie;
        this.capital = capital;
        this.nrAngajati = nrAngajati;
    }

    public String getNumeAgentie() {
        return numeAgentie;
    }

    public void setNumeAgentie(String numeAgentie) {
        this.numeAgentie = numeAgentie;
    }

    public float getCapital() {
        return capital;
    }

    public void setCapital(float capital) {
        this.capital = capital;
    }

    public int getNrAngajati() {
        return nrAngajati;
    }

    public void setNrAngajati(int nrAngajati) {
        this.nrAngajati = nrAngajati;
    }

    //metoda statica
    public static Agentie getInstance(String numeAgentie, float capital, int nrAngajati) {
        if(instance==null){
            instance = new Agentie(numeAgentie, capital, nrAngajati);
        }
        return instance;
    }
}
