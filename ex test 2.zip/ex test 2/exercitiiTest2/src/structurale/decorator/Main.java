package structurale.decorator;

public class Main {

    public static void main(String[] args) {
        INota notaDeSarbatori = new NotaDeSarbatori(new Nota(400));
        notaDeSarbatori.printareNota();
    }
}
