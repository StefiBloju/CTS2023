package structurale.decorator;

public interface INota {
    void printareNota();
}
