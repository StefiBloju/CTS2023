package structurale.decorator;

public class NotaDeSarbatori extends Decorator{

    public NotaDeSarbatori(Nota nota) {
        super(nota);
    }

    @Override
    public void printareNota() {
        super.printareNota();
        System.out.println("La multi ani");
    }
}
