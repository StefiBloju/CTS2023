package structurale.decorator;

public abstract class Decorator implements INota{

    private Nota nota;

    public Decorator(Nota nota) {
        this.nota = nota;
    }

    @Override
    public void printareNota() {
        nota.printareNota();
    }
}
