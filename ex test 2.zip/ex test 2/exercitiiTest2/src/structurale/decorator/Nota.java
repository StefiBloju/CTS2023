package structurale.decorator;

public class Nota implements INota{
    private double suma;

    public Nota(double suma) {
        this.suma = suma;
    }

    @Override
    public void printareNota() {
        System.out.println("Nota are valoarea " + suma);
    }
}
