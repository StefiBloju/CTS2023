package structurale.facade;

public class Facade {
    private final Restaurant restaurant;

    public Facade(Restaurant restaurant) {
        this.restaurant = restaurant;
    }

    public Masa intoarceMasa() {
        return restaurant.getMese().stream().filter(m-> m.iseLibera() && m.iseDebarasata() && m.isAreServeteleNoi()).findFirst().orElse(null);
    }
}
