package structurale.facade;

public class Masa {
    private boolean eLibera;
    private boolean eDebarasata;
    private boolean areServeteleNoi;

    public Masa(boolean eLibera, boolean eDebarasata, boolean areServeteleNoi) {
        this.eLibera = eLibera;
        this.eDebarasata = eDebarasata;
        this.areServeteleNoi = areServeteleNoi;
    }

    public boolean iseLibera() {
        return eLibera;
    }

    public void seteLibera(boolean eLibera) {
        this.eLibera = eLibera;
    }

    public boolean iseDebarasata() {
        return eDebarasata;
    }

    public void seteDebarasata(boolean eDebarasata) {
        this.eDebarasata = eDebarasata;
    }

    public boolean isAreServeteleNoi() {
        return areServeteleNoi;
    }

    public void setAreServeteleNoi(boolean areServeteleNoi) {
        this.areServeteleNoi = areServeteleNoi;
    }

    @Override
    public String toString() {
        return "Masa{" +
                "eLibera=" + eLibera +
                ", eDebarasata=" + eDebarasata +
                ", areServeteleNoi=" + areServeteleNoi +
                '}';
    }
}
