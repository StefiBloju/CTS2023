package structurale.facade;

public class Main {
    public static void main(String[] args) {
        Restaurant restaurant = new Restaurant();
        restaurant.adaugaMasa(new Masa(true, false, false));
        restaurant.adaugaMasa(new Masa(false,true,true));
        restaurant.adaugaMasa(new Masa(true,false,false));

        Facade facade = new Facade(restaurant);
        Masa masa = facade.intoarceMasa();
        if(masa != null) System.out.println(masa);
        else System.out.println("Nu exista o masa care sa corespunda");
    }
}
