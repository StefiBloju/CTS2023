package structurale.facade;

import java.util.ArrayList;
import java.util.List;

public class Restaurant {
    private final List<Masa> mese;

    public Restaurant() {
        this.mese = new ArrayList<>();
    }

    public List<Masa> getMese() {
        return mese;
    }

    public void adaugaMasa(Masa masa) {
        mese.add(masa);
    }
}
