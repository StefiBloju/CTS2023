package structurale.flyweight;

public interface ICamera {
    void tiparire(Rezervare rezervare);
}
