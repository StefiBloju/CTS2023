package structurale.adapter;

public class FacturaBar implements IFactura{
    private double suma;

    public FacturaBar(double suma) {
        this.suma = suma;
    }

    @Override
    public double printareFactura() {
        return suma;
    }
}
