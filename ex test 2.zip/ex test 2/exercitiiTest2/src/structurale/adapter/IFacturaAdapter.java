package structurale.adapter;

public interface IFacturaAdapter {
    double printareFactura();
}
