package structurale.adapter;

public class Main {
    public static void main(String[] args) {
        IFactura facturaBar = new FacturaBar(500);
        Adapter barAdapter = new Adapter(facturaBar);

        System.out.println("Factura pentru bar este " + facturaBar.printareFactura());
        System.out.println("Factura pentru bucatarie este " + barAdapter.printareFactura());
    }
}
