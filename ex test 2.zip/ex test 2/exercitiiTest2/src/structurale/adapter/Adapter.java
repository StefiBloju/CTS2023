package structurale.adapter;

public class Adapter implements IFacturaAdapter{
    private IFactura factura;

    public Adapter(IFactura factura) {
        this.factura = factura;
    }

    private double convertFacturi(double suma) {
        return suma * 1.1;
    }

    @Override
    public double printareFactura() {
        double sumaInitiala = factura.printareFactura();
        return convertFacturi (sumaInitiala);
    }
}
