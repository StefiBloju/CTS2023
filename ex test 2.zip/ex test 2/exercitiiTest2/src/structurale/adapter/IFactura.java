package structurale.adapter;

public interface IFactura {
    double printareFactura();
}
