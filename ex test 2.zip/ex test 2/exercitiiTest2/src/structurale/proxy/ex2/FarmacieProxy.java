package structurale.proxy.ex2;

public class FarmacieProxy implements IFarmacie{

    private final Farmacie farmacie;

    public FarmacieProxy(Farmacie farmacie) {
        this.farmacie = farmacie;
    }

    @Override
    public void vindeMedicament(Pacient pacient) {
        if(pacient.isAreReteta())
            farmacie.vindeMedicament(pacient);
        else
            System.out.println("Pacientul " + pacient.getNume() + " nu are reteta");
    }
}
