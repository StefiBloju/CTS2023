package structurale.proxy.ex2;

public class Pacient {

    private String nume;
    private boolean areReteta;

    public Pacient(String nume, boolean areReteta) {
        this.nume = nume;
        this.areReteta = areReteta;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public boolean isAreReteta() {
        return areReteta;
    }

    public void setAreReteta(boolean areReteta) {
        this.areReteta = areReteta;
    }

    @Override
    public String toString() {
        return "Pacient{" +
                "nume='" + nume + '\'' +
                ", areReteta=" + areReteta +
                '}';
    }
}
