package structurale.proxy.ex2;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        FarmacieProxy farmacieProxy = new FarmacieProxy(new Farmacie());

        List<Pacient> pacienti = new ArrayList<>();
        pacienti.add(new Pacient("a", true));
        pacienti.add(new Pacient("b", false));
        pacienti.add(new Pacient("c", false));
        pacienti.add(new Pacient("d", true));

        pacienti.forEach(p -> farmacieProxy.vindeMedicament(p));
    }
}
