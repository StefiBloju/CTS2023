package structurale.proxy.ex2;

public interface IFarmacie {

    void vindeMedicament(Pacient pacient);

}
