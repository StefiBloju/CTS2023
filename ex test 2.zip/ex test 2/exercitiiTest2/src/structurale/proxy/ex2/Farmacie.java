package structurale.proxy.ex2;

public class Farmacie implements IFarmacie{
    @Override
    public void vindeMedicament(Pacient pacient) {
        System.out.println("Medicament vandut catre pacientul " + pacient.getNume());
    }
}
