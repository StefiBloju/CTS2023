package structurale.proxy.ex1;

import java.util.List;
import java.util.stream.Collectors;

public class SpitalProxy implements ISpital{
    private Spital spital;

    public SpitalProxy(Spital spital) {
        this.spital = spital;
    }

    @Override
    public void interneazaPacienti(List<Pacient> pacienti) {
        List<Pacient> asigurati = pacienti.stream().filter(Pacient::isAreAsigurare).collect(Collectors.toList());
        spital.interneazaPacienti(asigurati);
    }

    @Override
    public List<Pacient> getInternati() {
        return spital.getInternati();
    }
}
