package structurale.proxy.ex1;

import java.util.List;

public interface ISpital {

    void interneazaPacienti(List<Pacient> pacienti);
    List<Pacient> getInternati();
}
