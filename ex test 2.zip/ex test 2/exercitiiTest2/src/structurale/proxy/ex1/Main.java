package structurale.proxy.ex1;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Spital spital = new Spital();

        List<Pacient> pacienti = new ArrayList<>();
        pacienti.add(new Pacient("ana", 10, true));
        pacienti.add(new Pacient("maria", 18, false));

        SpitalProxy spitalProxy = new SpitalProxy(spital);
        spitalProxy.interneazaPacienti(pacienti);

        System.out.println(spitalProxy.getInternati());
    }
}
