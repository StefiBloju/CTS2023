package structurale.proxy.ex1;

import java.util.ArrayList;
import java.util.List;

public class Spital implements ISpital{

    private final List<Pacient> internati;

    @Override
    public List<Pacient> getInternati() {
        return internati;
    }

    public Spital() {
        internati = new ArrayList<>();
    }

    public void interneazaPacienti(List<Pacient> pacienti) {
        internati.addAll(pacienti);
    }
}
