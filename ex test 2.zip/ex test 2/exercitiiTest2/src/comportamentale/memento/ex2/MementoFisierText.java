package comportamentale.memento.ex2;

//comportamentale.memento

public class MementoFisierText {

    private final String text;

    public MementoFisierText(String textDeSalvat) {
        text = textDeSalvat;
    }

    public String getText() {
        return text;
    }
}
