package comportamentale.memento.ex2;

//originator

public class FisierText {

    public StringBuilder continut;
    public String nume;

    public FisierText(String nume){
        this.continut = new StringBuilder();
        this.nume = nume;
    }

    public void adaugaText(String text){
        continut.append(text);
    }

    public MementoFisierText salveaza() {
        System.out.println("Salvare stare text");
        return new MementoFisierText(this.continut.toString());
    }

    public void ctrlZ(MementoFisierText salvare){
        this.continut = new StringBuilder();
        this.continut.append(salvare.getText());
    }

    public String getText(){
        return this.continut.toString();
    }

}
