package comportamentale.memento.ex2;

import java.util.ArrayList;
import java.util.List;

//manager stari

public class Notepad {

    private List<MementoFisierText> salvari = new ArrayList<MementoFisierText>();


    public void addSalvare(MementoFisierText salvare){
        this.salvari.add(salvare);
    }

    public MementoFisierText recupereazaUltimaSalvare(){
        if(salvari.size()!=0){
            MementoFisierText salvare =  salvari.get(salvari.size()-1);
            salvari.remove(salvari.size()-1);
            return salvare;
        }
        else
            return new MementoFisierText("");
    }

}
