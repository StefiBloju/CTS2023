package comportamentale.memento.ex1;

public class PachetTuristic {

    public double pret;
    public String numePachet;

    public double getPret() {
        return pret;
    }

    public void setPret(double pret) {
        this.pret = pret;
    }


    public PachetTuristic(double pret) {
        this.pret = pret;
    }

    @Override
    public String toString() {
        return "PachetTuristic{" +
                "pret=" + pret +
                '}';
    }

    public MementoPachetTuristic salvareMemento() {
        return new MementoPachetTuristic(pret);
    }

    public void undoToMemento(MementoPachetTuristic memento) {
        this.pret = memento.getPretPachet();
    }
}
