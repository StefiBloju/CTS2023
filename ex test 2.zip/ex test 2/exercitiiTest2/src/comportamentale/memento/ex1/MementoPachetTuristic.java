package comportamentale.memento.ex1;

public class MementoPachetTuristic {

    double pretPachet;

    public MementoPachetTuristic(double pretPachet) {
        this.pretPachet = pretPachet;
    }

    public double getPretPachet() {
        return pretPachet;
    }
}
