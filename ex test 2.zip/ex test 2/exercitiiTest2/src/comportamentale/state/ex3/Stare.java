package comportamentale.state.ex3;

public interface Stare {

    void doAction();
}
