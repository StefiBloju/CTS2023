package comportamentale.state.ex3;

public class Main {
    public static void main(String[] args) {

        Loc loc1 = new Loc(1);
        Loc loc2 = new Loc(3);
        loc1.rezervaLoc();
        loc1.ocupaLoc();
        loc2.eliberareLoc();
        loc2.ocupaLoc();
        loc1.eliberareLoc();
    }
}
