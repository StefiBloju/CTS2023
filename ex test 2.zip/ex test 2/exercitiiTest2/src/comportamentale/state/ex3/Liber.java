package comportamentale.state.ex3;

public class Liber implements Stare{

    @Override
    public void doAction() {
        System.out.println("Locul este liber");
    }
}
