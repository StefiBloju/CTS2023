package comportamentale.state.ex3;

public class Rezervat implements Stare{

    @Override
    public void doAction() {
        System.out.println("Locul este rezervat");
    }
}
