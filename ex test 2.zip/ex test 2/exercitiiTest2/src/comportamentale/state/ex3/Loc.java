package comportamentale.state.ex3;

public class Loc {

    private int nrLoc;

    private Stare stare;

    public Loc(int nrLoc) {
        this.nrLoc = nrLoc;
        stare = new Liber();
    }

    public void rezervaLoc() {
        if(this.stare instanceof Liber) {
            System.out.println("Locul cu nr " + nrLoc + " este rezervat");
            stare = new Rezervat();
        } else {
            System.out.println("Locul cu numarul " + nrLoc + " nu poate fi rezervat");
        }
    }

    public void ocupaLoc() {
        if(this.stare instanceof Ocupat) {
            System.out.println("Locul cu nr " + nrLoc + " este ocupat");
            stare = new Ocupat();
        } else {
            System.out.println("Locul cu numarul " + nrLoc + " nu poate fi ocupat");
        }
    }

    public void eliberareLoc() {
        if(this.stare instanceof Liber) {
            System.out.println("Locul cu nr " + nrLoc + " este eliberat");
            stare = new Liber();
        } else {
            System.out.println("Locul cu numarul " + nrLoc + " este deja liber");
        }
    }

}
