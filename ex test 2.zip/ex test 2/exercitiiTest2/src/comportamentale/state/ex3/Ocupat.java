package comportamentale.state.ex3;

public class Ocupat implements Stare{
    @Override
    public void doAction() {
        System.out.println("Locul este ocupat");
    }
}
