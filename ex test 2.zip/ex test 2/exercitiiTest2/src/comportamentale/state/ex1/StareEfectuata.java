package comportamentale.state.ex1;

public class StareEfectuata implements Stare{

    @Override
    public void doAction(Rezervare rezervare) {
        System.out.println("Rezervare cu id-ul " + rezervare.getId()+ " este trecuta in stare EFECTUATA");
        rezervare.setState(this);
    }
}
