package comportamentale.state.ex1;

public interface Stare {

    void doAction (Rezervare rezervare);
}
