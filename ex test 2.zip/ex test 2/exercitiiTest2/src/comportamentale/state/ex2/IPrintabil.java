package comportamentale.state.ex2;

public interface IPrintabil {

    void print(String text);

}
