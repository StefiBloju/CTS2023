package comportamentale.state.ex2;

public enum Stare {
    NORMAL, BOLD, ITALIC;

}
