package comportamentale.state.ex2;

public class StareNormal implements IPrintabil{

    @Override
    public void print(String text) {
        System.out.println("Normal " + text);
    }
}
