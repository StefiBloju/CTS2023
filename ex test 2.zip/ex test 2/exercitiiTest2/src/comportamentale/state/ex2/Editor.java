package comportamentale.state.ex2;

public class Editor {

    IPrintabil stareCurenta;

    public Editor(){
        stareCurenta = (IPrintabil) new StareNormal();
    }

    public void setStare(Stare stare){
        if(stare == Stare.NORMAL)
            this.stareCurenta = (IPrintabil) new StareNormal();
        else
        if(stare == Stare.BOLD)
            this.stareCurenta = new StareBold(this);
        else
            this.stareCurenta = (IPrintabil) new StareItalic();
    }

    public void afisare(String text){
        this.stareCurenta.print(text);
    }
}

