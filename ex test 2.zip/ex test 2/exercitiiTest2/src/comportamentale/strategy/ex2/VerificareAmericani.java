package comportamentale.strategy.ex2;

public class VerificareAmericani implements ModVerificare{
    @Override
    public void verificaActe(String nume) {
        System.out.println("Am verificat viza americana a lui " + nume);
    }
}
