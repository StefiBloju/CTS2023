package comportamentale.strategy.ex2;

public class Main {
    public static void main(String[] args) {
        Client client = new Client("Aurel", new VerificareEuropeniUE());
        client.verificaDocumente();

        Client client2 = new Client("Joe", new VerificareAmericani());
        client2.verificaDocumente();

    }
}
