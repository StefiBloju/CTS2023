package comportamentale.strategy.ex2;

public class VerificareNonUE implements ModVerificare{
    @Override
    public void verificaActe(String nume) {
        System.out.println("Am verificat viza non-europeana a lui " + nume);
    }
}
