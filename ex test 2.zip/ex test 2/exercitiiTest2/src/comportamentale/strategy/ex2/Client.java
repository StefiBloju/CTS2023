package comportamentale.strategy.ex2;

public class Client {

    public String nume;
    public ModVerificare modVerificare;

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public ModVerificare getModVerificare() {
        return modVerificare;
    }

    public void setModVerificare(ModVerificare modVerificare) {
        this.modVerificare = modVerificare;
    }

    public Client(String nume, ModVerificare modVerificare) {
        this.nume = nume;
        this.modVerificare = modVerificare;
    }

    public void verificaDocumente() {
        modVerificare.verificaActe(nume);
    }
}
