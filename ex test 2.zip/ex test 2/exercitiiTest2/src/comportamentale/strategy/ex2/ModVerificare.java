package comportamentale.strategy.ex2;

public interface ModVerificare {
    void verificaActe(String nume);
}
