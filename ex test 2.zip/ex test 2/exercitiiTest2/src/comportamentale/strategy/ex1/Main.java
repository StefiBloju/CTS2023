package comportamentale.strategy.ex1;

public class Main {
    public static void main(String[] args) {
        Client client1 = new Client("Ana");
        Client client2 = new Client("Maria");

        client1.setModPlata(new Card());
        client1.plateste(300);

        client2.setModPlata(new Cash());
        client2.plateste(100);
    }
}
