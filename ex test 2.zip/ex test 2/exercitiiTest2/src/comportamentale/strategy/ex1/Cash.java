package comportamentale.strategy.ex1;

public class Cash implements ModPlata{
    @Override
    public void plateste(String numeClient, double sumaPlatita) {
        System.out.println(numeClient + " plateste cash suma de " + sumaPlatita);
    }
}
