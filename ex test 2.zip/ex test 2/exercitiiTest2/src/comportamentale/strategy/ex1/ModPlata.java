package comportamentale.strategy.ex1;

public interface ModPlata {
    void plateste(String numeClient, double sumaPlatita);
}
