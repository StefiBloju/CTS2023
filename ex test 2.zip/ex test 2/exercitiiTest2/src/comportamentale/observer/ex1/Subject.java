package comportamentale.observer.ex1;

public interface Subject {

    void adaugaObserver(Observer observer);
    void stergeObserver(Observer observer);
    void trimiteNotificare(String mesaj);
}
