package comportamentale.observer.ex1;

public class Main {

    public static void main(String[] args) {
        ClientFidel clientPopescu = new ClientFidel("Popescu");

        Agentie agentie = new Agentie("AgeTur");

        agentie.adaugaObserver(clientPopescu);
        agentie.notificareReducerePret();

    }

}
