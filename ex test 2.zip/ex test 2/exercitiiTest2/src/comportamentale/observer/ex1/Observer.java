package comportamentale.observer.ex1;

public interface Observer {

    public void receptionareMesaj(String mesaj);
}
