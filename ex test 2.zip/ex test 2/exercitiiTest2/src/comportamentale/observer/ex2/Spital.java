package comportamentale.observer.ex2;

import java.util.ArrayList;
import java.util.List;

public class Spital implements Observabil{

    private List<Observator> listaobservatori;
    private String numeVirus;

    public Spital(String numeVirus) {
        this.numeVirus = numeVirus;
        listaobservatori = new ArrayList<Observator>();
    }

    @Override
    public void abonareObservator(Observator observator) {
        listaobservatori.add(observator);
    }

    @Override
    public void dezabonareObservator(Observator observator) {
        listaobservatori.remove(observator);
    }

    @Override
    public void notificareObservator(String mesaj) {
        for (Observator observator:listaobservatori) {
            observator.notifica(numeVirus + ":" + mesaj);
        }
    }
}
