package comportamentale.observer.ex2;

public class Main {

    public static void main(String[] args) {
        Pacient pacientAna = new Pacient("Ana");

        Spital spital = new Spital("Covid");

        spital.abonareObservator(pacientAna);
        spital.notificareObservator("mesaj");
    }

}
