package comportamentale.observer.ex2;

public interface Observabil {

    void abonareObservator (Observator observator);

    void dezabonareObservator (Observator observator);

    void notificareObservator (String mesaj);
}
