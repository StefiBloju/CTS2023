package comportamentale.observer.ex2;

public interface Observator {
    public void notifica(String mesaj);
}
