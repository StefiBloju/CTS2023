package comportamentale.observer.ex2;

public class Pacient implements Observator {

    private String nume;

    public Pacient(String nume) {
        this.nume = nume;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    @Override
    public void notifica(String mesaj) {
        System.out.printf("Pacientul ", nume, " a primit ", mesaj);
    }
}
